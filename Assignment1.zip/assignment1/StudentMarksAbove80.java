package assignment1;

public class StudentMarksAbove80 {

	public static void main(String[] args) {
		
		int marks[] = {78,12,89,55,35};
		
		for(int i : marks) 
		{
			if(i > 80) 
			{
				System.out.println("Student mark above 80 is: "+i);
			}
			
		}

	}

}
