package assignment4;

import java.util.ArrayList;
import java.util.List;

public class SecondAndSecondLast {

	public static void main(String[] args) {
		
		List<Integer> i1 = new ArrayList<>();
		
		i1.add(10);
		i1.add(45);
		i1.add(90);
		i1.add(45);
		i1.add(45);
		i1.add(90);
		i1.add(44);
		
		
		i1.remove(0);
		
		int last = i1.size() -1;
		
		i1.remove(last);
		
		int newLast = i1.size() -1;
		
		System.out.println(i1.get(0));
		System.out.println(i1.get(newLast));
		
		
	}

}
