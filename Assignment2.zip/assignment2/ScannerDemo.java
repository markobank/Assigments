package assignment2;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the number of students");
		
		int n1 = sc.nextInt();
		
		System.out.println("Please enter name");
		
		String name1 = sc.nextLine();
		
		System.out.println("Please enter email");
		
		String email1 = sc.next();
		
		System.out.println("Please enter phone");
		
		Long phone1 = sc.nextLong();
		
		System.out.println("Please enter adress");
		
		String adress1 = sc.next();
		
		System.out.println("Please enter status");
		
		String status1 = sc.next();
		
		System.out.println("Please enter name");
		
		String name2 = sc.next();
		
		System.out.println("Please enter email");
		
		String email2 = sc.next();
		
		System.out.println("Please enter phone");
		
		Long phone2 = sc.nextLong();
		
		System.out.println("Please enter adress");
		
		String adress2 = sc.next();
		
		System.out.println("Please enter status");
		
		String status2 = sc.next();
		
		System.out.println("Please enter name");
		
		String name3 = sc.next();
		
		System.out.println("Please enter email");
		
		String email3 = sc.next();
		
		System.out.println("Please enter phone");
		
		Long phone3 = sc.nextLong();
		
		System.out.println("Please enter adress");
		
		String adress3 = sc.next();
		
		System.out.println("Please enter status");
		
		String status3 = sc.next();
		
		System.out.println("Please enter which student details are you looking for");
		
		n1 = sc.nextInt();
		
		switch (n1){
		
			case 1: n1 = 1;
			System.out.println(name1 +"\n" + email1 +"\n" + phone1 +"\n" + adress1 +"\n" + status1);
			
				break;
				
			case 2: n1 = 2;
			System.out.println(name2 +"\n" + email2 +"\n" + phone2 +"\n" + adress2 +"\n" + status2);
			
				break;
				
			case 3: n1 = 3;
			System.out.println(name3 +"\n" + email3 +"\n" + phone3 +"\n" + adress3 +"\n" + status3);
			
				break;

			default:
				break;
		}
		
		sc.close();


	}

}
