package assignment4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListOfLists {

	public static void main(String[] args) {
		
		List<List<Integer>> mainList = new ArrayList<>();
		
		List<Integer> l1 = Arrays.asList(11,22,33);
		
		List<Integer> l2 = Arrays.asList(9,19,29);
		
		List<Integer> l3 = Arrays.asList(7,17,27);
		
		mainList.add(l1);
		mainList.add(l2);
		mainList.add(l3);
		
		System.out.println(mainList);
		

	}

}
