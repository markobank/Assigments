package assignment4;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class RemoveDuplicates {

	public static void main(String[] args) {
		
		List<String> l1 = new ArrayList<>();
		
		l1.add("Java");
		l1.add("TestNG");
		l1.add("Maven");
		l1.add("Java");
		
		System.out.println(l1);
		
		HashSet<String> h1 = new HashSet<>(l1);
		
		System.out.println(h1);
	}

}
