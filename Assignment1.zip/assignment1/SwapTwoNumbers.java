package assignment1;

public class SwapTwoNumbers {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		
		a = 20;
		b = 10;
		
		System.out.println("a = "+a);
		System.out.println("b = "+b);

	}

}
