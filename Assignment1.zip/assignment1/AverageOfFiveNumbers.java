package assignment1;

public class AverageOfFiveNumbers {

	public static void main(String[] args) {
		
		int a = 10;
		double b = 90.78;
		int c = 111;
		int d = 8989;
		int e = 7876;
		
		double avr = (a + b + c + d + e)/5;
		
		System.out.println("Average of five numbers is: " + avr);

	}

}
