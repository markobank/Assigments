package assignment2;


public class Trainer {
	
	public String name;
	public String it;
	public String email;
	public int id;
	public String teach;
	
	public Trainer(String name, String it, String email, int id ) 
	{
		this.name = name;
		this.it = it;
		this.email = email;
		this.id = id;
		
	}
	
	public String setTech(String teach) 
	{
		this.teach = teach;
		return teach;
	}
	
	
	//this method is just for testing
	
	public void display() 
	{
		System.out.println(name + " " + it + " " + email + " " + id + " " + teach);
	}


	public static void main(String[] args) 
	{
		Trainer tr [] = new Trainer[3];
		tr[0] = new Trainer("Mukesh", "Testing", "mukesh@gmail.com", 1);
		tr[1] = new Trainer("Hitech", "Dev", "mukesh@gmail.com", 2);
		tr[2] = new Trainer("Mukesh", "DevOps", "mukesh@gmail.com" , 3);
		
		tr[0].setTech("Selenium");
		tr[1].setTech("Web Development");
		tr[2].setTech("DevOps");
		
		tr[0].display();
		tr[1].display();
		tr[2].display();
	}

	
}
