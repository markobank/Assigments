package assignment1;

public class BreakAtWordSelenium {

	public static void main(String[] args) {
		
		String words[] = {"Java","JavaScript","Selenium","Python","Mukesh"};
		
		for(String word : words) 
		{
			if(word.equals("Selenium")) 
			{
				break;
			}
			
			System.out.println("Next word is: " + word);
		}

	}

}
