package assignment1;

public class BreakAtNumber85 {

	public static void main(String[] args) {
		
		int num[] = {12,34,66,85,900};
		
		for(int i : num) 
		{
			if(i == 85)
			{	
				
				break;
			}
			System.out.println("I found number: " + i);
		}

	}

}
