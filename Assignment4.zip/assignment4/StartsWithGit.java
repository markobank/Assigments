package assignment4;

import java.util.ArrayList;
import java.util.List;

public class StartsWithGit {

	public static void main(String[] args) 
	{
		
		
		List<String> l2 = new ArrayList<>();
		
		l2.add("Git");
		l2.add("Github");
		l2.add("GitLab");
		l2.add("GitBash");
		l2.add("Selenium");
		l2.add("Java");
		l2.add("Maven");
		
		List<String> l3 = new ArrayList<>();
		
		for(String x : l2) 
		{
			if(x.startsWith("Git")) 
			{
				l3.add(x);
			}
		}
		
		System.out.println(l3);

	}

}
